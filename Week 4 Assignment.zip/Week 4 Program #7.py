def generate_salary_schedule(starting_salary, percentage_increase, num_years):
    print("Year\tSalary")
    print("------------------")
    salary = starting_salary

    for year in range(1, num_years + 1):
        print(year, "\t$", format(salary, ".2f"))
        salary += salary * (percentage_increase / 100)

# Get the inputs from the user
starting_salary = float(input("Enter the starting salary: "))
percentage_increase = float(input("Enter the percentage increase: "))
num_years = int(input("Enter the number of years: "))

# Generate and display the salary schedule
generate_salary_schedule(starting_salary, percentage_increase, num_years)
