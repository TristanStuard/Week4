def approximate_pi(iterations):
    result = 0
    sign = 1

    for i in range(iterations):
        term = sign / (2 * i + 1)
        result += term
        sign *= -1

    return 4 * result

# Get the number of iterations from the user
num_iterations = int(input("Enter the number of iterations: "))

# Call the function to approximate pi and display the result
approximation = approximate_pi(num_iterations)
print("Approximated value of pi:", approximation)
